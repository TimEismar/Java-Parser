
/**
 * Write a description of class Herausforderung here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Herausforderung
{
    GroßeHerausforderung temp = new GroßeHerausforderung();
    public Herausforderung()
    {
       //Constructor 
    }
    
    
    public void checker(String w){
        temp.checker(w);
    }
}
